package database

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import model.Game

@Database(entities = [Game::class], version = 1, exportSchema = false)
abstract class GameBacklogDatabase : RoomDatabase() {

    abstract fun gameDao(): GameDao

    companion object {
        private const val DATABASE_NAME = "BACKLOG_DATABASE"

        @Volatile
        private var backlogRoomDatabaseInstance: GameBacklogDatabase? = null

        fun getDatabase(context: Context): GameBacklogDatabase? {
            if (backlogRoomDatabaseInstance == null) {
                synchronized(GameBacklogDatabase::class.java) {
                    if (backlogRoomDatabaseInstance == null) {
                        backlogRoomDatabaseInstance =
                            Room.databaseBuilder(
                                context.applicationContext,
                                GameBacklogDatabase::class.java,
                                DATABASE_NAME
                            )
                                .build()
                    }
                }
            }
            return backlogRoomDatabaseInstance
        }
    }
}