package model

import android.os.Parcelable
import androidx.room.Entity
import kotlinx.android.parcel.Parcelize
import androidx.room.ColumnInfo
import androidx.room.PrimaryKey

@Parcelize
@Entity
data class Game(
    @ColumnInfo(name = "title")
    var title: String,
    @ColumnInfo(name = "platform")
    var platform: String,
    @ColumnInfo(name = "day")
    var day: String,
    @ColumnInfo(name = "month")
    var month: String,
    @ColumnInfo(name = "year")
    var year: String,
    @ColumnInfo(name = "id")
    @PrimaryKey
    var id: Long? = null
) : Parcelable