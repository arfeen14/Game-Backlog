package database

import android.content.Context
import androidx.lifecycle.LiveData
import model.Game

public class gameBacklogRepository(context: Context) {

    private var gameDao: GameDao

    init {
        val backlogRoomDatabase =
            GameBacklogDatabase.getDatabase(context)
        gameDao = backlogRoomDatabase!!.gameDao()
    }

    fun getAllBacklogs(): LiveData<List<Game>> {
        return gameDao.getAllGames()
    }

    suspend fun insertBacklog(backlog: Game) {
        gameDao.insertGame(backlog)
    }

    suspend fun deleteBacklog(backlog: Game) {
        gameDao.deleteGame(backlog)
    }

}