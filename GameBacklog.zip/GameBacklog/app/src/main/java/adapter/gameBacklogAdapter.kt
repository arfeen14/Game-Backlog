package adapter

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.example.gamebacklog.R
import kotlinx.android.synthetic.main.item_gamebacklog.view.*
import model.Game

class gameBacklogAdapter(private val backlog: List<Game>) :
    RecyclerView.Adapter<gameBacklogAdapter.ViewHolder>() {

    inner class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {


        fun bind(game: Game) {
            itemView.tvTitle.text = game.title
            itemView.tvConsole.text = game.platform
            itemView.tvDate.text = game.day.plus("-").plus(game.month).plus("-").plus(game.year)
        }

    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        return ViewHolder(
            LayoutInflater.from(parent.context).inflate(R.layout.item_gamebacklog, parent, false)
        )
    }

    override fun getItemCount(): Int {
        return backlog.size
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        holder.bind(backlog[position])
    }
}