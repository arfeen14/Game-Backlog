package ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.LiveData
import database.gameBacklogRepository
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import model.Game

class MainActivityViewModel(application: Application) : AndroidViewModel(application) {

    private val ioSCope = CoroutineScope(Dispatchers.IO)
    private val backlogRepository = gameBacklogRepository(application.applicationContext)


    val backlog: LiveData<List<Game>> =
        backlogRepository.getAllBacklogs()

    fun insertBacklog(backlog: Game) {
        ioSCope.launch {
            backlogRepository.insertBacklog(backlog)
        }
    }


    fun deleteBacklog(backlog: Game) {
        ioSCope.launch {
            backlogRepository.deleteBacklog(backlog)
        }
    }
}