package ui

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.gamebacklog.R
import kotlinx.android.synthetic.main.activity_main.*
import kotlinx.android.synthetic.main.content_edit.*
import model.Game

const val EXTRA_BACKLOG = "EXTRA_BACKLOG"

class AddActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_edit)


        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        initViews()
    }

    private fun initViews() {
        fab.setOnClickListener { onMakeClick() }
    }

    private fun onMakeClick() {
        if (tvTitle.text.toString().isNotBlank() and
            tvConsole.text.toString().isNotBlank() and
            etDag.text.toString().isNotBlank() and
            etMaand.text.toString().isNotBlank() and
            etJaar.text.toString().isNotBlank()
        ) {
            val backlog = Game(
                tvTitle.text.toString(),
                tvConsole.text.toString(),
                etDag.text.toString(),
                etMaand.text.toString(),
                etJaar.text.toString()
            )

            val resultIntent = Intent()
            resultIntent.putExtra(EXTRA_BACKLOG, backlog)
            setResult(Activity.RESULT_OK, resultIntent)
            finish()
        } else {
            Toast.makeText(
                this, "fill the requirements"
                , Toast.LENGTH_SHORT
            ).show()

        }
    }
}